<link href="css/monta.css" rel="stylesheet"/>
<?php if($pdf): ?>
	<iframe src="<?php echo $pdfFile;?>" style="position: absolute; top: 0; left: 0;width: 100vw; height: 100vh;"></iframe>
<?php else: ?>
	<button class="btn btn-primary generar-pdf-btn" onclick="window.location = 'montahtml.php?IdAsignatura=<?php echo $IdAsignatura; ?>&IdIdioma=<?php echo $IdIdioma;?>&CursoAcademico=<?php echo $CursoAcademico; ?>&pdf'">Generar PDF</button>
	
	<?php
	require $htmlFile;
	?>
	<button class="btn btn-primary generar-pdf-btn" onclick="window.location = 'montahtml.php?IdAsignatura=<?php echo $IdAsignatura; ?>&IdIdioma=<?php echo $IdIdioma;?>&CursoAcademico=<?php echo $CursoAcademico; ?>&pdf'">Generar PDF</button>
<?php endif; ?>

