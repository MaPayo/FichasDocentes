<?php
require_once '../vendor/autoload.php';

require_once 'lib/GenDocs.php';

/**************************************************************************************/

$IdAsignatura = $_GET['IdAsignatura'];
$IdIdioma = $_GET['IdIdioma'];
$CursoAcademico = $_GET['CursoAcademico'];
$pdf = isset($_GET['pdf']);

$genDocs = new GenDocs($IdAsignatura, $IdIdioma, $CursoAcademico);
$folder = 'output';
if(!is_dir($folder)) {
	mkdir($folder);
}
$name = str_replace('/', '-', $CursoAcademico) . '_' . $IdIdioma . '_' . $IdAsignatura;
$htmlFile = "$folder/$name.html";
$pdfFile = "$folder/$name.pdf";

if($pdf) {
	if(!is_file($htmlFile)) {
		$genDocs->genHTML($htmlFile);		
	}
	$genDocs->genPDF($pdfFile, $htmlFile);	
} else {
	$genDocs->genHTML($htmlFile);
}

require 'view/showHtml.php';
?>
