<?php
require_once '../vendor/autoload.php';
require_once 'model/connect.php';
require_once 'model/GuiaDocenteModel.php';

class GenDocs {
	private $idAsignatura;
	private $idIdioma;
	private $curcoAcademico;

	private $pandoc;

	public function __construct($idAsignatura, $idIdioma, $cursoAcademico){
		$this->idAsignatura = $idAsignatura;
		$this->idIdioma = $idIdioma;
		$this->cursoAcademico = $cursoAcademico;
		$this->pandoc = $pandoc = new Pandoc\Pandoc();
	}

	public function genPDF($filename, $htmlPath = null) {
		if($htmlPath == null) {
			$htmlPath = 'myFile.html';
			$this->genHTML($htmlPath);
		}
		$content = file_get_contents($htmlPath);

		// instantiate and use the dompdf class
		$dompdf = new Dompdf\Dompdf();
		$dompdf->loadHtml($content);

		$dompdf->setPaper('A4', 'portrait');
		//$dompdf->setPaper(array(0,0,821.86,756.00),'executive'); //x inicio, y inicio, ancho final, alto final
		//$dompdf->set_option('defaultFont', 'Courier');
		// Render the HTML as PDF
		$dompdf->render();

		// Output the generated PDF to Browser
		//$dompdf->stream($filename);
		$output = $dompdf->output();
		file_put_contents($filename, $output);
	}

	public function genHTML($filename) {
		// TABLA GRADO
		$rowNombreGrado = GuiaDocenteModel::getNombreGradoByIdAsignatura($this->idAsignatura);
		if ($rowNombreGrado)
		{
			$NombreGradoHTML = $this->convertMarkdownToHTML($rowNombreGrado["NombreGrado"]);
		}
		else
		{
			$NombreGradoHTML = '';
		}

		// TABLA ASIGNATURA
		$rowAsignatura = GuiaDocenteModel::getAsignaturaByIdAsignatura($this->idAsignatura);

		if ($rowAsignatura)
		{
			$NombreAsignaturaHTML = $this->convertMarkdownToHTML($rowAsignatura["NombreAsignatura"]);
			$NombreAsignaturainglesHTML = $this->convertMarkdownToHTML($rowAsignatura["NombreAsignaturaIngles"]);
			$CursoHTML = $this->convertMarkdownToHTML($rowAsignatura["Curso"]);
			$SemestreHTML = $this->convertMarkdownToHTML($rowAsignatura["Semestre"]);
			$NombreAsignaturaInglesHTML = $this->convertMarkdownToHTML($rowAsignatura["NombreAsignaturaIngles"]);
			$CreditosHTML = $this->convertMarkdownToHTML($rowAsignatura["Creditos"]);
		}
		else
		{
			$NombreAsignaturaHTML=$MateriaHTML=$ModuloHTML=$CaracterHTML=$CursoHTML=$SemestreHTML=$NombreAsignaturaInglesHTML=$CreditosMateriaHTML=$CreditosMateriaHTML=$CreditosHTML=$CoordinadoresHTML='';
		}

		if ($this->idIdioma == 'ingles')
		{
			$NombreAsignaturaHTML = $NombreAsignaturainglesHTML;
		}

		// TABLA MATERIA
		$rowMateria = GuiaDocenteModel::getMateriaByIdAsignatura($this->idAsignatura);

		if ($rowMateria)
		{
			$NombreMateriaHTML = $this->convertMarkdownToHTML($rowMateria["NombreMateria"]);
		}
		else
		{
			$NombreMateriaHTML = '';
		}


		// TABLA MODULO
		$rowModulo = GuiaDocenteModel::getModuloByIdAsignatura($this->idAsignatura);

		if ($rowModulo)
		{
			$NombreModuloHTML = $this->convertMarkdownToHTML($rowModulo["NombreModulo"]);
			$CaracterHTML = $this->convertMarkdownToHTML($rowModulo["Caracter"]);
		}
		else
		{
			$NombreModuloHTML= $CaracterHTML='';
		}

		// TABLA TEORICO
		$rowTeorico = GuiaDocenteModel::getTeoricoByIdAsignatura($this->idAsignatura);

		if ($rowTeorico)
		{
			$CreditosTeoricoHTML = $this->convertMarkdownToHTML($rowTeorico["Creditos"]);
			/*$PresencialHTML = $this->convertMarkdownToHTML($rowTeorico["Presencial"]) . "%";
			*/
			$PresencialHTML = $rowTeorico["Presencial"] . "%";
			$HorasTeorico =  ceil(filter_var( $rowTeorico["Creditos"], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) * 25 * (float) filter_var( $rowTeorico["Presencial"], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) / 100);
		}
		else 
		{
			$CreditosTeoricoHTML = $PresencialHTML = $HorasTeorico = $HorasTeorico = '';
		}

		// TABLA PROBLEMA
		$rowProblema = GuiaDocenteModel::getProblemaByIdAsignatura($this->idAsignatura);

		if ($rowProblema)
		{
			$CreditosProblemaHTML = $this->convertMarkdownToHTML($rowProblema["Creditos"]);
			/*
			$PresencialProblemaHTML = $this->convertMarkdownToHTML($rowProblema["Presencial"]) . "%";
			*/
			$PresencialProblemaHTML = $rowProblema["Presencial"] . "%";
			$HorasProblema = ceil(filter_var( $rowProblema["Creditos"], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) * 25 * (float) filter_var( $rowProblema["Presencial"], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) / 100);
		}
		else
		{
			$CreditosProblemaHTML=$PresencialProblemaHTML=$HorasProblema='';
		}


		// TABLA LABORATORIO
		$rowLaboratorio = GuiaDocenteModel::getLaboratorioByIdAsignatura($this->idAsignatura);

		if ($rowLaboratorio)
		{
			$CreditosLaboratorioHTML = $this->convertMarkdownToHTML($rowLaboratorio["Creditos"]);
			/*
			$PresencialLaboratorioHTML = $this->convertMarkdownToHTML($rowLaboratorio["Presencial"]) . "%";
			*/
			$PresencialLaboratorioHTML = $rowLaboratorio["Presencial"] . "%";
			$HorasLaboratorio = ceil(filter_var( $rowLaboratorio["Creditos"], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) * 25 * (float) filter_var( $rowLaboratorio["Presencial"], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION ) / 100);
		}
		else
		{
			$CreditosLaboratorioHTML=$PresencialLaboratorioHTML=$HorasLaboratorio='';
		}

		// TABLA PROFESOR (el coordinador)  *************************************

		$rowProfesorCoordinador = GuiaDocenteModel::getProfesorCoordinadorByIdAsignatura($this->idAsignatura);

		if ($rowProfesorCoordinador)
		{
			$EmailHTML = $this->convertMarkdownToHTML($rowProfesorCoordinador["Email"]);
			$DepartamentoHTML = $this->convertMarkdownToHTML($rowProfesorCoordinador["Departamento"]);
			$DespachoHTML = $this->convertMarkdownToHTML($rowProfesorCoordinador["Despacho"]);
			$CoordinadorHTML = $this->convertMarkdownToHTML($rowProfesorCoordinador["Nombre"]);


		}
		else
		{
			$EmailHTML=$DepartamentoHTML=$DespachoHTML='';
		}	

		// TABLA COMPETENCIAASIGNATURA Y RESULTADOS DE APRENDIZAJE ***********

		$rowCompetencias = GuiaDocenteModel::getCompetenciasByIdAsignatura($this->idAsignatura);


		if ($rowCompetencias)
		{
			$GeneralesHTML = $this->convertMarkdownToHTML($rowCompetencias["Generales"]);
			$GeneralesiHTML = $this->convertMarkdownToHTML($rowCompetencias["Generalesi"]);
			$EspecificasHTML = $this->convertMarkdownToHTML($rowCompetencias["Especificas"]);
			$EspecificasiHTML = $this->convertMarkdownToHTML($rowCompetencias["Especificasi"]);
			$BasicasYTransversalesHTML = $this->convertMarkdownToHTML($rowCompetencias["BasicasYTransversales"]);

			$BasicasYTransversalesiHTML = $this->convertMarkdownToHTML($rowCompetencias["BasicasYTransversalesi"]);
			$ResultadosAprendizajeHTML = $this->convertMarkdownToHTML($rowCompetencias["ResultadosAprendizaje"]);
			$ResultadosAprendizajeiHTML = $this->convertMarkdownToHTML($rowCompetencias["ResultadosAprendizajei"]);
		}
		else
		{
			$GeneralesHTML=$GeneralesiHTML=$EspecificasHTML=$EspecificasiHTML=$BasicasYTransversalesHTML=$BasicasYTransversalesiHTML=$ResultadosAprendizajeHTML=$ResultadosAprendizajeiHTML = '';
		}

		if ($this->idIdioma == 'ingles')
		{
			$GeneralesHTML = $GeneralesiHTML;
			$EspecificasHTML = $EspecificasiHTML;
			$BasicasYTransversalesHTML = $BasicasYTransversalesiHTML;
			$ResultadosAprendizajeHTML = $ResultadosAprendizajeiHTML;
		}

		// TABLA PROGRAMAASIGNATURA

		$rowPrograma = GuiaDocenteModel::getProgramaByIdAsignatura($this->idAsignatura);

		if ($rowPrograma)
		{
			$ConocimientosPreviosHTML = $this->convertMarkdownToHTML($rowPrograma["ConocimientosPrevios"]);
			$ConocimientosPreviosiHTML = $this->convertMarkdownToHTML($rowPrograma["ConocimientosPreviosi"]);
			$BreveDescripcionHTML = $this->convertMarkdownToHTML($rowPrograma["BreveDescripcion"]);
			$BreveDescripcioniHTML = $this->convertMarkdownToHTML($rowPrograma["BreveDescripcioni"]);
			$ProgramaDetalladoHTML = $this->convertMarkdownToHTML($rowPrograma["ProgramaDetallado"]);
			$ProgramaDetalladoiHTML = $this->convertMarkdownToHTML($rowPrograma["ProgramaDetalladoi"]);
		}
		else
		{
			$ConocimientosPreviosHTML=$ConocimientosPreviosiHTML=$BreveDescripcionHTML=$BreveDescripcioniHTML=$ProgramaDetalladoHTML=$ProgramaDetalladoiHTML = '';
		}
		if ($this->idIdioma == 'ingles')
		{
			$ConocimientosPreviosHTML = $ConocimientosPreviosiHTML;
			$BreveDescripcionHTML = $BreveDescripcioniHTML;
			$ProgramaDetalladoHTML = $ProgramaDetalladoiHTML;
		}


		// TABLA BIBLIOGRAFIA  ***********************************************************

		$rowBibliografia = GuiaDocenteModel::getBibliografiaByIdAsignatura($this->idAsignatura);

		if ($rowBibliografia)
		{
			$CitasBibliograficasHTML = $this->convertMarkdownToHTML($rowBibliografia["CitasBibliograficas"]);
			$RecursosInternetHTML = $this->convertMarkdownToHTML($rowBibliografia["RecursosInternet"]);
		}
		else
		{
			$CitasBibliograficasHTML=$RecursosInternetHTML = '';
		}

		// TABLA METODOLOGIA **************************************************************

		$rowMetodologia = GuiaDocenteModel::getMetodologiaByIdAsignatura($this->idAsignatura);

		if ($rowMetodologia)
		{
			$MetodologiaHTML = $this->convertMarkdownToHTML($rowMetodologia["Metodologia"]);
			$MetodologiaiHTML = $this->convertMarkdownToHTML($rowMetodologia["Metodologiai"]);
		}
		else
		{
			$MetodologiaHTML = '';

			$MetodologiaiHTML = '';
		}
		if ($this->idIdioma == 'ingles')
		{
			$MetodologiaHTML = $MetodologiaiHTML;
		}


		// TABLA EVALUACION *****************************************************************

		$rowEvaluacion = GuiaDocenteModel::getEvaluacionByIdAsignatura($this->idAsignatura);

		if ($rowEvaluacion)
		{
			$RealizacionExamenesHTML = $this->convertMarkdownToHTML($rowEvaluacion["RealizacionExamenes"]);
			$RealizacionExamenesiHTML = $this->convertMarkdownToHTML($rowEvaluacion["RealizacionExamenesi"]);
			$PesoExamenesHTML = $this->convertMarkdownToHTML($rowEvaluacion["PesoExamenes"]);
			$CalificacionFinalHTML = $this->convertMarkdownToHTML($rowEvaluacion["CalificacionFinal"]);
			$CalificacionFinaliHTML = $this->convertMarkdownToHTML($rowEvaluacion["CalificacionFinali"]);
			$RealizacionActividadesHTML = $this->convertMarkdownToHTML($rowEvaluacion["RealizacionActividades"]);
			$RealizacionActividadesiHTML = $this->convertMarkdownToHTML($rowEvaluacion["RealizacionActividadesi"]);
			$PesoActividadesHTML = $this->convertMarkdownToHTML($rowEvaluacion["PesoActividades"]);
			$RealizacionLaboratorioHTML = $this->convertMarkdownToHTML($rowEvaluacion["RealizacionLaboratorio"]);
			$RealizacionLaboratorioiHTML = $this->convertMarkdownToHTML($rowEvaluacion["RealizacionLaboratorioi"]);
			$PesoLaboratorioHTML = $this->convertMarkdownToHTML($rowEvaluacion["PesoLaboratorio"]);
		}
		else
		{
			$RealizacionExamenesHTML = $RealizacionExamenesiHTML = $PesoExamenesHTML = $CalificacionFinalHTML = $CalificacionFinaliHTML = $RealizacionActividadesHTML = $RealizacionActividadesiHTML = $PesoActividadesHTML = $RealizacionLaboratorioHTML = $RealizacionLaboratorioiHTML = $PesoLaboratorioHTML = '';
		}
		if ($this->idIdioma == 'ingles')
		{
			$RealizacionExamenesHTML = $RealizacionExamenesiHTML;
			$CalificacionFinalHTML = $CalificacionFinaliHTML;
			$RealizacionActividadesHTML = $RealizacionActividadesiHTML;
			$RealizacionLaboratorioHTML = $RealizacionLaboratorioiHTML;
		}


		// CONSULTA PROFESORES ******************************************************

		$rowsgrupoClaseProfesor = GuiaDocenteModel::getProfesoresByIdAsignatura($this->idAsignatura);

		if ($rowsgrupoClaseProfesor)
		{
			$rowsgrupoClaseProfesor = $this->convertRowFieldsFromMarkdowmToHTML($rowsgrupoClaseProfesor);
		}

		// CONSULTA HORARIOS CLASES  ************************************************

		$rowsHorario = GuiaDocenteModel::getHorariosClasesByIdAsignatura($this->idAsignatura);

		$rowcountHorario =sizeof($rowsHorario);



		// CONSULTA TUTORÍAS  *************************************************************

		$rowsTutorias = GuiaDocenteModel::getTutoriasByIdAsignatura($this->idAsignatura);
		
		$tutoriaConcatenadas="";
		foreach($rowsTutorias as $row)
		{
			$tutoriaConcatenadas .= $row['Nombre']."  ".$row['Tutoria']."<br>";
		}
		$tutoriaConcatenadas = $this->convertMarkdownToHTML($tutoriaConcatenadas);

		

		// CONSULTA HORARIOS LABORATORIOS *************************************************************
		
		$rowsHorarioLab = GuiaDocenteModel::getLaboratoriosByIdAsignatura($this->idAsignatura);
		
	/***********************************************************************/
		ob_clean();
		ob_start();

		$cursoAcademico = $this->cursoAcademico;
		$idAsignatura = $this->idAsignatura;

		if ($this->idIdioma == 'español')
		{
			require 'view/guiaDocenteTemplate.php';
		}
		else
		{
			require 'view/guiaDocenteTemplateIngles.php';
		}
		
		$content = ob_get_contents();
		ob_clean();
		file_put_contents($filename, $content);
	}

	/****************************************************************************/

	private function convertMarkdownToHTML($markdown) {
		$html = '';
		if (!empty($markdown))
		{
			$html = $this->pandoc->convert($markdown, "markdown_github", "html");
		}

		return $html;
	}

	private function convertRowFieldsFromMarkdowmToHTML($rows) {
		$convertedRows = array();
		foreach ($rows as $row) {
			$convertedRow = array();
			foreach ($row as $key => $value) {
				$html = $this->convertMarkdownToHTML($value);
				$convertedRow[$key] = $html;
			}

			$convertedRows[] = $convertedRow;
		}

		return $convertedRows;
	}
}
