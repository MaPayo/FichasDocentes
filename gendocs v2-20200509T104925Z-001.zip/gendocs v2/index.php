<html>
<head>
	<title>gendocs</title>
	<link rel="stylesheet" type="text/css" href="css/formulario.css" media="all" />
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />


</head>

<body>
	<h2>GENDOCS</h2>
	<form id="formulario" action="montahtml.php" method="get">
		<fieldset>
			<legend>Generación de la ficha docente</legend>
				<p>
				<label>Asignatura:</label>
				<select id="IdAsignatura" name="IdAsignatura" required> 
					<option value="804560" >FísicaI (grado de ing. electrónica)</option>
					<option value="800509" >Mecánica Cuántica (grado en Física)</option>
					<option value="804522" >Materiales poliméricos (grado en Ingeniería de Materiales)</option>
					<option value="804600" >Redes de Computadores (grado de ing. electrónica)</option>
				</select>
				</p>

				<p>
				<label>Idioma:</label>
				<select id="IdIdioma" name="IdIdioma" required> 
					<option value="español" selected="selected">Español</option>
					<option value="ingles">Inglés</option>
				</select>
				</p>

				<p>
				<label>Curso académico</label>
					<input id="CursoAcademico" name="CursoAcademico" type="text" maxlength="18" value="2020/2021" required /> 
				</p>
		</fieldset>
		<input id="enviar" name="enviar" type="submit" value="Enviar" />
		<?php
		echo "<p>Se va a llamar a gendocs()</p>";
		?>
	</form>
</html>

	
	
