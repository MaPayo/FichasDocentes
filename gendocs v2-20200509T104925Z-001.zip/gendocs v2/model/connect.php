<?php
	// conexion a la BBDD
	define('DATABASE_USERNAME', 'u701525375_guiasdoc');
	define('DATABASE_PASSWORD', 'guiasdoc');
	define('DATABASE_HOST', '31.220.20.82');
	define('DATABASE_DBNAME', 'u701525375_guiasdoc');

    // Create connection
	//$conn = new mysqli(DATABASE_HOST, DATABASE_USERNAME, DATABASE_PASSWORD, DATABASE_DBNAME);
    //$conn = mysqli_connect($servername, $username, $password, $database);
    // Check connection
    /*if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    echo "Connected successfully";*/

    require_once 'Connection.php';
    Connection::connect(DATABASE_HOST, DATABASE_USERNAME, DATABASE_PASSWORD, DATABASE_DBNAME);
    //Connection::$conn = $conn;
?>