<?php
class Connection {
    public static $conn;

    public static function connect($host, $user, $pwd, $db) {
    	$conn = new mysqli($host, $user, $pwd, $db);

    	if (!$conn) {
        	die("Connection failed: " . mysqli_connect_error());
    	}
    	echo "Connected successfully";

    	self::$conn = $conn;
    }

    public static function query($sql) {
		return mysqli_query(self::$conn, $sql);
	}
}