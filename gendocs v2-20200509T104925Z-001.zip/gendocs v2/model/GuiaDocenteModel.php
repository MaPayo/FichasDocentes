<?php
class GuiaDocenteModel {
	
	public static function getNombreGradoByIdAsignatura($IdAsignatura) {
		$sql = "SELECT NombreGrado FROM grado gr, asignatura asi, materia ma, modulo mo WHERE (IdAsignatura='$IdAsignatura') and (ma.IdMateria = asi.IdMateria) and (ma.IdModulo = mo.IdModulo) and (mo.CodigoGrado = gr.CodigoGrado) ";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getMateriaByIdAsignatura($IdAsignatura) {
		$sql = "SELECT NombreMateria FROM materia ma, asignatura asi WHERE IdAsignatura='$IdAsignatura' and (ma.IdMateria = asi.IdMateria)";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getModuloByIdAsignatura($IdAsignatura) {
		$sql = "SELECT NombreModulo, Caracter FROM modulo mo, asignatura asi, materia ma WHERE IdAsignatura='$IdAsignatura' and (ma.IdMateria = asi.IdMateria) and (ma.IdModulo = mo.IdModulo)";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getAsignaturaByIdAsignatura($IdAsignatura) {
		$sql = "SELECT NombreAsignatura, Curso, Semestre, NombreAsignaturaIngles, Creditos, Coordinadores FROM asignatura WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getTeoricoByIdAsignatura($IdAsignatura) {
		$sql = "SELECT Creditos, Presencial FROM teorico WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getProblemaByIdAsignatura($IdAsignatura) {
		$sql = "SELECT Creditos, Presencial FROM problema WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getLaboratorioByIdAsignatura($IdAsignatura) {
		$sql = "SELECT Creditos, Presencial FROM laboratorio WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getProfesorCoordinadorByIdAsignatura($IdAsignatura) {
		$sql = "SELECT Email, Nombre, Departamento, Despacho FROM profesor, asignatura WHERE (IdAsignatura='$IdAsignatura' and profesor.Email = asignatura.Coordinadores)";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getCompetenciasByIdAsignatura($IdAsignatura) {
		$sql = "SELECT Generales, Generalesi, Especificas, Especificasi, BasicasYTransversales, BasicasYTransversalesi, ResultadosAprendizaje, ResultadosAprendizajei FROM competenciaasignatura WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getProgramaByIdAsignatura($IdAsignatura) {
		$sql = "SELECT ConocimientosPrevios, ConocimientosPreviosi, BreveDescripcion, BreveDescripcioni, ProgramaDetallado, ProgramaDetalladoi FROM programaasignatura WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getBibliografiaByIdAsignatura($IdAsignatura) {
		$sql = "SELECT CitasBibliograficas, RecursosInternet FROM bibliografia WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getMetodologiaByIdAsignatura($IdAsignatura) {
		$sql = "SELECT Metodologia, Metodologiai  FROM metodologia WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getEvaluacionByIdAsignatura($IdAsignatura) {
		$sql = "SELECT RealizacionExamenes, RealizacionExamenesi, PesoExamenes, CalificacionFinal, CalificacionFinali, RealizacionActividades, RealizacionActividadesi, PesoActividades, RealizacionLaboratorio, RealizacionLaboratorioi, PesoLaboratorio FROM evaluacion WHERE IdAsignatura='$IdAsignatura'";
		$result = Connection::query($sql);
		$row = mysqli_fetch_assoc($result);
		return $row;
	}

	public static function getProfesoresByIdAsignatura($IdAsignatura) {
		$sql = "SELECT Letra, Nombre, Departamento, pr.Email 
			FROM grupoclase gc, grupoclaseprofesor cp, profesor pr
			WHERE IdAsignatura='$IdAsignatura' and (gc.IdGrupoClase = cp.IdGrupoClase) and (cp.EmailProfesor = pr.Email) order by  Letra";
		$result = Connection::query($sql);
		$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
		return $rows;
	}

	public static function getHorariosClasesByIdAsignatura($IdAsignatura) {
		$sql = "SELECT Letra, Dia, HoraInicio, HoraFin, Aula
		FROM grupoclase gc, horarioclase hc
		WHERE IdAsignatura='$IdAsignatura' and (gc.IdGrupoClase = hc.IdGrupoClase)";

		$result = Connection::query($sql);
		$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
		return $rows;
	}

	public static function getTutoriasByIdAsignatura($IdAsignatura) {
		$sql = "SELECT DISTINCT Nombre, Tutoria 
		FROM grupoclase gc, grupoclaseprofesor cp, profesor pr
		WHERE IdAsignatura='$IdAsignatura' and (gc.IdGrupoClase = cp.IdGrupoClase) and (cp.EmailProfesor = pr.Email)";

		$result = Connection::query($sql);
		$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
		return $rows;
	}

	public static function getLaboratoriosByIdAsignatura($IdAsignatura) {
		$sql = "SELECT DISTINCT Letra, Dia, HoraInicio, HoraFin, Laboratorio, Nombre
		FROM grupolaboratorio gl, horariolaboratorio hl, profesor pr, grupolaboratorioprofesor gp
		WHERE IdAsignatura='$IdAsignatura' and (hl.IdGrupoLab = gl.IdGrupoLab) and (gl.IdGrupoLab = gp.IdGrupoLab) and (pr.Email = gp.EmailProfesor)";

		$result = Connection::query($sql);
		$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
		return $rows;
	}



}
